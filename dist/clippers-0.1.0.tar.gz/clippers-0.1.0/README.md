# Clippers

Clippers is a Python library that allows you to convert Markdown to HTML and vice-versa, as well as Markdown-ifying and HTML-ifying text.

## The `Clippers` class
The library comes with 1 class, the `Clippers` class. This holds the following methods.

### Class methods

