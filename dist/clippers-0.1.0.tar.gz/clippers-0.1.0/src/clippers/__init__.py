from utils import Clippers, detect_html, detect_markdown
